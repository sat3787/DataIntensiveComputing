#####################################################
# Implementing various Plotting schemes and functions 
#####################################################

### Loading libraries
library(ggplot2)
library(doBy)

### Load the data set into the object
DisastersData<-read.csv("NaturalDisasters.csv")
counts<-table(DisastersData$Country)
Lowest<-quantile(counts,.08)
Highest<-quantile(counts,.90)

### Barplots 
barplot(counts[counts>Highest],las=2,main="Countries with most number of natural disasters",ylab="count of disasters",col="red")
barplot(counts[counts<Lowest],las=2,main="Countries with least number of natural disasters",ylab="count of disasters",col="green")
Dis.Frequency<-table(DisastersData$Type)
barplot(Dis.Frequency,main="Frequency of Natural Disasters",ylab="count of disasters",col="yellow",cex.names= 0.75,ylim=c(0,4000),las=2)

### Defining the functions
MyFunc<-function(x){c(sum(as.numeric(x)),length(x))}
MySum<-function(x){c(sum(as.numeric(x)))}
Frame1<-aggregate(Killed~Type,DisastersData,FUN=MyFunc)
Frame2<-aggregate(Cost~Type,DisastersData,FUN= MySum)
Frame3<-aggregate(Affected~Type,DisastersData,FUN= MySum)
DataByTypes<-data.frame(Frame1$Type,Frame1$Killed,Frame2$Cost,Frame3$Affected)
colnames(DataByTypes)<-c("Type","Killed","Frequency","Cost","Affected")

### Scatter plot based on the number of deaths and loss of capital
plot(DataByTypes$Frequency,DataByTypes$Killed,xlab="Frequency of Disasters",ylab="Persons Killed",pch=as.integer(DataByTypes$Type),col=DataByTypes$Type,type='p',main="Frequency vs Number of Deaths")
legend("topright",levels(DataByTypes$Type),pch=1:length(levels(DataByTypes$Type)),cex=0.35,title="Type",col=1:length(levels(DataByTypes$Type)))

### Classify the number of deaths by the type of disasters
plot(DataByTypes[c("Type","Killed")],col="red",las=2,xlab=NULL,main="Classifying deaths by Types")

### Histogram plots
ggplot(subset(DisastersData,Killed < 100),aes(x=Killed,fill=Type)) + geom_histogram(binwidth=1)+ggtitle("Frequency of disasters with Low death rate")

### Boxplots for number of deaths
ggplot(subset(DisastersData,Killed>4000),aes(x=Type,y=Killed,fill=Type))+geom_boxplot()+ggtitle("Deaths due to various types of disasters")
ggplot(subset(DisastersData,Killed>1000),aes(x=Type,y=Killed,fill=Type))+geom_boxplot()+ggtitle("Deaths due to various types of disasters")

### Boxplots for drought
ggplot(subset(DisastersData,Type %in% c("Drought")),aes(x=Type,y=Cost,fill=Type))+geom_boxplot()+coord_flip()+ggtitle("Capital Loss due to droughts")

### Density plots
ggplot(subset(DisastersData,Killed>100000),aes(x=Killed,colour=Type))+geom_density()+ggtitle("Density curves for deaths greater than 0.1 million")
ggplot(subset(DisastersData,Cost>10000000),aes(x=Cost,colour=Type))+geom_density()+ggtitle("Loss of capital more than 10 million")

### Summary functions and objects
sum_Deaths_ByCountry<-summaryBy(Killed~Country,data=DisastersData,FUN=function(y){c(sum=sum(y),mean=mean(y),med=median(y),min=min(y),max=max(y))})
sum_Deaths_ByTypes<-summaryBy(Killed~Type,data=DisastersData,FUN=function(y){c(sum=sum(y),mean=mean(y),med=median(y),min=min(y),max=max(y))})