
##############################################
# Plotting the locations of earthquakes in USA
##############################################

### Loading the libraries
library(ggmap)
library(mapproj)

### Read the data from the csv file
DisastersData<-read.csv("NaturalDisasters.csv")

### Create a data subset of all the records pertaining to Earthquakes in USA 
USA_Earthquakes<-subset(DisastersData,Country %in% c("United States") & Type %in% c("Earthquake (seismic activity)"),drop=TRUE)

### Create an empty data frame for saving the coordinates of locations
CoordinatesDF<-data.frame(lon=character(),lat=character())
for(i in USA_Earthquakes$Location){
  newrow<-geocode(i)
  CoordinatesDF=rbind(CoordinatesDF,newrow)
}

### Append the coordinates to the existing data set
USA_Earthquakes$lon<-CoordinatesDF$lon
USA_Earthquakes$lat<-CoordinatesDF$lat

### Obtain the map 
map<-get_map(location="north america",zoom=3,maptype="terrain")
p<-ggmap(map)

### Plot the points using the longitudes and latitudes retreived earlier
p <- p + geom_point(data = USA_Earthquakes,aes(x = lon, y = lat, shape =23, colour="red",fill="red"), size = 3) + scale_shape_identity()
#p <- p + geom_text(data = USA_Earthquakes,aes(x = lon, y = lat, label = Location,cex=.05), hjust = -0.2)
p <- p + theme( legend.position = "none",panel.grid.major = element_blank(),panel.grid.minor = element_blank(), axis.text = element_blank(), axis.title = 
                  element_blank(), axis.ticks = element_blank())
p<-p+labs(title="Earthquakes in USA")
print(p)    
