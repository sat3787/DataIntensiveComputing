
#######################################
# Mapping the earthquakes in the world
#######################################

### loading the required libraries
library(rworldmap)

### Read the data set into the object
DisastersData<-read.csv("NaturalDisasters.csv")

### Creating a subset for records pertaining to earthquakes
Earthquakes_DF<-subset(DisastersData,Type %in% c("Earthquake (seismic activity)"),drop=TRUE)
Frame_01<-aggregate(Killed~Country,data=Earthquakes_DF,sum)
Frame_02<-aggregate(Killed~Country,data=Earthquakes_DF,length)
EQ_DataByCountry<-data.frame(Frame_01$Country,Frame_01$Killed,Frame_02$Killed)
colnames(EQ_DataByCountry)<-c("Country","Killed","Frequency")

### Plotting the values to worldmap and creating bubbles
EQ_pdf<-joinCountryData2Map(EQ_DataByCountry,joinCode="NAME",nameJoinColumn="Country",nameCountryColumn="Country",verbose=FALSE)
op <- palette(c('white','lightpink','pink','green','purple','orange','red'))
EQ_mapParams<-mapCountryData(EQ_pdf,nameColumnToPlot="Killed",colourPalette='palette',addLegend=FALSE,oceanCol='lightyellow',mapTitle='Deaths due to Earthquakes',missingCountryCol='lightgrey')
do.call( addMapLegend, c(EQ_mapParams, legendWidth=0.5, legendMar = 2,legendLabels="all"))
mapDevice("windows")
MyBubble<-mapBubbles(EQ_pdf,nameZSize="Frequency",nameZColour="GEO3major",colourPalette='heat',oceanCol='lightyellow',landCol='grey',addColourLegend=FALSE,pch=23,legendPos='bottomright',legendTitle="Frequency",legendHoriz=TRUE,plotZeroVals=TRUE,borderCol='white',legendBg='lightgrey')
title(main="Number of Earthquakes",cex.main=1.5,font.main=3,col.main="red")
