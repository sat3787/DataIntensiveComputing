setwd("C:\\DIC\\MyWorkingDirectory")
#############################
# Plotting data to world map
#############################

### Loading libraries
library(rworldmap)
library(doBy)

### Load the data set into the object
DisastersData<-read.csv("NaturalDisasters.csv")

### Group by Countries
Frame_A<-aggregate(Killed~Country,data=DisastersData,sum)
Frame_B<-aggregate(Killed~Country,data=DisastersData,length)
DataByCountry<-data.frame(Frame_A$Country,Frame_A$Killed,Frame_B$Killed)
colnames(DataByCountry)<-c("Country","Killed","Frequency")

### Mapping to the worldmap
sPDF<-joinCountryData2Map(DataByCountry,joinCode="NAME",nameJoinColumn="Country",nameCountryColumn="Country",verbose=FALSE)
op <- palette(c('green','lavender','yellow','pink','purple','orange','red'))
mapParams<-mapCountryData(sPDF,nameColumnToPlot="Frequency",colourPalette='palette',addLegend=FALSE,oceanCol='lightblue',mapTitle='Frequency of Disasters',missingCountryCol='white')
do.call( addMapLegend, c(mapParams, legendWidth=0.5, legendMar = 2,legendLabels="all"))

### Bubbling to the map
mapDevice("windows")
FrequencyBubble<-mapBubbles(sPDF,nameZSize="Killed",nameZColour="GEO3major",colourPalette='rainbow',oceanCol='lightblue',landCol='wheat',addColourLegend=FALSE,pch=21,legendPos='bottom',legendTitle="Number of Deaths",legendHoriz=TRUE,plotZeroVals=TRUE,borderCol='white',legendVals=c(10000,50000,100000,200000,300000,500000),legendBg="lightgrey")
title(main="Deaths caused by disasters",cex.main=1.5,font.main=2,col.main="blue")

