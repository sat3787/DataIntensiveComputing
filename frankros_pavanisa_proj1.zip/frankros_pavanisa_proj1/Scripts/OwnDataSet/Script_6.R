
############################
# K-Means Clustering: Type2
############################

library(ggplot2)
library(rworldmap)
library(ggmap)
library(mapproj)
library(doBy)

### Read the data set from the csv file
DisastersData<-read.csv("NaturalDisasters.csv")
MyFunc<-function(z){c(sum(as.numeric(z)))}
Fr1<-aggregate(Killed~Country,DisastersData,FUN=MyFunc)
Fr2<-aggregate(Cost~Country,DisastersData,FUN=MyFunc)
ClusterData<-data.frame(Fr1$Country,Fr1$Killed,Fr2$Cost)
colnames(ClusterData)<-c("Country","TotalKilled","TotalCost")
ClusterFrame<-data.frame(ClusterData$TotalKilled,ClusterData$TotalCost)

### Perform K-means clustering using the number of clusters as 3
Kmeans_results<-kmeans(ClusterFrame,3)

### Plot the resultant clusters using different colours
plot(ClusterFrame[Kmeans_results$cluster==1,],
     col="red",
     xlim=c(min(ClusterFrame[,1]),max(ClusterFrame[,1])),
     ylim=c(min(ClusterFrame[,2]),max(ClusterFrame[,2]))
)
points(ClusterFrame[Kmeans_results$cluster==2,],col="black")
points(ClusterFrame[Kmeans_results$cluster==3,],col="seagreen")

#######################################################
# Visualizing the results of Kmeans using a GLOBAL MAP
#######################################################

LonLat<-data.frame(lon=character(),lat=character())
for(i in ClusterData$Country){
  newrow<-geocode(i)
  LonLat=rbind(LonLat,newrow)
}

### Append the coordinates to the existing data set
ClusterData$lon<-LonLat$lon
ClusterData$lat<-LonLat$lat
ClusterData$cluster<-Kmeans_results$cluster

### Obtain the map 
map=getMap(resolution= "low")
plot(map)
points(ClusterData$lon,ClusterData$lat,pch=22,col=ClusterData$cluster,bg=ClusterData$cluster,cex=1.5)
title(main="Visualization of K Means using K=3 ",cex.main=1.5,font.main=2,col.main="blue")
