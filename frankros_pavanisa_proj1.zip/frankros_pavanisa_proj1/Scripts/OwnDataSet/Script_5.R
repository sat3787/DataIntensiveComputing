
############################
# K-Means Clustering: Type1
############################

### Read the data set from the csv file
DisastersData<-read.csv("NaturalDisasters.csv",header=TRUE)

### Create the data frame that contains no groupings or classes
FrequencyFrame<-data.frame(DisastersData$Killed,DisastersData$Cost)

### Check the data frame that hass been created
head(FrequencyFrame)

### Perform K-means clustering using the number of clusters as 5
results<-kmeans(FrequencyFrame,5)

### Plot the resultant clusters using different colours
plot(FrequencyFrame[results$cluster==1,],
     col="red",
     xlim=c(min(FrequencyFrame[,1]),max(FrequencyFrame[,1])),
     ylim=c(min(FrequencyFrame[,2]),max(FrequencyFrame[,2]))
     )
points(FrequencyFrame[results$cluster==2,],col="blue")
points(FrequencyFrame[results$cluster==3,],col="seagreen")
points(FrequencyFrame[results$cluster==4,],col="black")
points(FrequencyFrame[results$cluster==5,],col="purple")





