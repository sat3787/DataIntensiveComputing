require(gdata)
require(COUNT)
#Grader: Please replace the read.xls() parameter with your local file of rollingsales_manhattan
mh <- read.xls("/Users/frankrossi/Downloads/doing_data_science-master/dds_datasets/dds_ch2_rollingsales/rollingsales_manhattan.xls")
head(mh)
summary(mh)
colnames(mh) <- c("BOROUGH","NEIGHBORHOOD","BUILDING.CLASS.CATEGORY","TAX.CLASS.AT.PRESENT","BLOCK","LOT","EASE-MENT","BUILDING.CLASS.AT.PRESENT","ADDRESS","APARTMENT.NUMBER","ZIP.CODE","RESIDENTIAL.UNITS","COMMERCIAL.UNITS","TOTAL.UNITS","LAND.SQUARE.FEET","GROSS.SQUARE.FEET","YEAR.BUILT","TAX.CLASS.AT.TIME.OF.SALE","BUILDING.CLASS.AT.TIME.OF.SALE","SALE.PRICE","SALE.DATE")

mh$SALE.PRICE.N <- as.numeric( gsub("[^[:digit:]]","", mh$SALE.PRICE))
count(is.na(mh$SALE.PRICE.N))
names(mh) <- tolower(names(mh))

mh$gross.sqft <- as.numeric(gsub("[^[:digit::]]","",mh$gross.square.feet))
mh$sqft <- as.numeric(gsub("[^[:digit:]]","", mh$land.square.feet))
mh$sale.date <- as.Date(mh$sale.date,"%Y-%m-%d")
mh$year.built <- as.numeric(as.character(mh$year.built))

hist(mh$sale.price.n)
hist(mh$sale.price.n[mh$sale.price.n>0])
hist(mh$gross.sqft[mh$sale.price.n == 0])

mh.sale <- mh[mh$sale.price.n != 0,]
mh.sale$sale.date <- as.Date(mh.sale$sale.date, "%Y-%m-%d")

plot(mh.sale$gross.sqft, mh.sale$sale.price.n)
plot(log(mh.sale$gross.sqft), log(mh.sale$sale.price.n))

#1, 2, 3 - family homes
mh.homes <- mh.sale[which(grepl("FAMILY",mh.sale$building.class.category)),]
plot(log(mh.homes$gross.sqft),log(mh.homes$sale.price.n))

mh.homes[ which( mh.homes $ sale.price.n < 100000),] [order( mh.homes[ which( mh.homes $ sale.price.n < 100000),] $ sale.price.n),]

mh.homes$outliers <- (log(mh.homes$sale.price.n) <=5) + 0
mh.homes <- mh.homes[which(mh.homes$outliers==0),]

plot(log(mh.homes$gross.sqft), log(mh.homes$sale.price.n))
require(ggplot2)
#analysis across time
ggplot() + geom_line(aes(x=mh.sale$sale.date,y=mh.sale$sale.price.n))

mh.sale1 <- subset(mh.sale,mh.sale$sale.price.n != "N/A")
mh.neighborhood <- aggregate(sale.price.n~neighborhood, data=mh.sale, sum)
plot(mh.neighborhood[c("neighborhood", "sale.price.n")],las=2, cex.axis = .35)
