#Grader: Please change the setwd() parameter to your directory which stores all 31 nyt.csv files
setwd("/Users/frankrossi/Downloads/doing_data_science-master/dds_datasets/dds_ch2_nyt")
file_list <- list.files()
my.data <- list()
for(i in 1:length(file_list)){
	data1 <- read.csv(file_list[[i]])
	head(data1)
	data1$agecat<-cut(data1$Age, c(-Inf,018,24,34,44,54,64,Inf))
	summary(data1)
	library(doBy)
	siterange<-function(x){c(length(x),min(x),mean(x),max(x))}
	summaryBy(Age~agecat, data = data1, FUN = siterange)
	summaryBy(Gender+Signed_In+Impressions+Clicks ~ agecat, data = data1)
	library(ggplot2)
	ggplot(data1,aes(x = Impressions, fill = agecat)) + geom_histogram(binwidth = 1)
	ggplot(data1,aes(x = agecat, y = Impressions, fill = agecat)) + geom_boxplot()
	data1$hasimps <- cut(data1$Impressions,c(-Inf,0,Inf))
	summaryBy(Clicks~hasimps, data = data1, FUN = siterange)

	ggplot( subset( data1,Impressions > 0), aes(x = Clicks/Impressions, colour = 	agecat)) + geom_density()

	ggplot( subset( data1, Clicks > 0), aes( x = Clicks/ Impressions, colour = agecat)) + geom_density()

	ggplot( subset( data1, Clicks > 0), aes( x = agecat, y = Clicks, fill = agecat)) + geom_boxplot()

	ggplot( subset( data1, Clicks > 0), aes( x = Clicks, colour = agecat)) + geom_density()

	data1$scode[data1$Impressions == 0] <- "NoImps"
	data1$scode[data1$Impressions > 0] <- "Imps"
	data1$scode[data1$Clicks > 0] <- "Clicks"

	data1$scode <- factor(data1$scode)
	summary(data1$scode)

	clen<- function(x){c(length(x))}
	etable<-summaryBy(Impressions~scode+Gender+agecat,data=data1,FUN=clen)
  
	ggplot(subset(data1,data1$Age<18),aes(x=Gender))+geom_density()
	ggplot(data1,aes(x= Signed_In))+geom_density()

	data1$impcat<-cut(data1$Impressions,c(-Inf,0,5,10,Inf))
	summaryBy(Impressions+Clicks~impca+Gender,data = data1, FUN = c(var,length,sd))
	
	my.data[[i]] <- data1
}

yImp <- seq(length(my.data))
for(i in 1:length(my.data))
{
	yImp[i] <- sum(my.data[[i]]["Clicks"]/my.data[[i]]["Impressions"], na.rm=TRUE)
}

days <- seq(length(my.data))
cat <- cut(yImp, c(0,800,10000,12000,14000,Inf))
ggplot() + geom_line(aes(x=days,y=yImp)) +(aes(x=days,y=yImp,fill=cat))
ggplot() + geom_line(aes(x=days,y=yImp))
